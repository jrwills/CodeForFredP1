﻿#region UnitIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
using Fredburger.Source.Gameplay.World.Units.Mobs; //Tomato, Potato, Lettuce
#endregion

namespace Fredburger.Source.Gameplay.World
{
    /// <summary>
    /// 
    /// </summary>
    public class SpawnPoint : Basic2D
    {
        public bool dead;

        public float hitDistance;

        public EngTimer spawnTimer = new EngTimer(2200); //2.2 seconds

        /// <summary>
        /// Constructor (needs same arguments since inherits from Basic2D
        /// </summary>
        public SpawnPoint(string fp, Vector2 p, Vector2 d) : base(fp, p, d) //??
        {
            dead = false; //initially false when a new mob is created

            hitDistance = 35.0f;
        }

        /// <summary>
        /// Override
        /// </summary>
        public override void Update(Vector2 offset)
        {
            spawnTimer.UpdateTimer();
            if(spawnTimer.Test())
            {
                SpawnMob();
                //SpawnMob2(); spawns them at the exact same time
                //SpawnMob3();
                spawnTimer.ResetToZero();
            }
            base.Update(offset);
        }


        public virtual void SpawnMob()
        {
            GameGlobals.PassMob(new Tomato(new Vector2(pos.X, pos.Y))); //passes mob to AddMob() in World
        }
        public virtual void SpawnMob2()
        {
            GameGlobals.PassMob(new Potato(new Vector2(pos.X, pos.Y))); //passes mob to AddMob() in World
        }
        public virtual void SpawnMob3()
        {
            GameGlobals.PassMob(new Lettuce(new Vector2(pos.X, pos.Y))); //passes mob to AddMob() in World
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Collision() // "get hit"
        {
            dead = true;
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
