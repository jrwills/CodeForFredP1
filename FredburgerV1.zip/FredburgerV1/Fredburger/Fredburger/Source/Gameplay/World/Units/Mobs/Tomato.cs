﻿#region TomatoIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
using Fredburger.Source.Gameplay.World.Projectiles; //Bullet
#endregion

namespace Fredburger.Source.Gameplay.World.Units.Mobs
{
    /// <summary>
    /// 
    /// </summary>
    public class Tomato : Mob
    {
        //speed is inherited from Unit


        /// <summary>
        /// Constructor (needs same arguments since inherits from unit
        /// - 11:09 p2
        /// </summary>
        public Tomato(Vector2 p) : base("2D\\Units\\Mobs\\tomato", p, new Vector2(40,40)) //(40,40)
        {
            speed = 1.0f;
        }

        /// <summary>
        /// Inputs for the Hero
        /// </summary>
        public override void Update(Vector2 offset, Hero hero)
        {
            base.Update(offset, hero);
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
