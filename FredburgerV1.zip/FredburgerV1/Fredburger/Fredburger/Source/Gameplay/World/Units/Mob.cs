﻿#region MobIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
using Fredburger.Source.Gameplay.World.Projectiles; //Bullet
using Fredburger.Source.Gameplay.World; //Unit
using Fredburger.Source.Gameplay.World.Units; //Hero
#endregion

namespace Fredburger.Source.Gameplay.World.Units
{
    /// <summary>
    /// 
    /// </summary>
    public class Mob : Unit
    {
        //speed is inherited from Unit


        /// <summary>
        /// Constructor (needs same arguments since inherits from unit
        /// - 11:09 p2
        /// </summary>
        public Mob(string fp, Vector2 p, Vector2 d) : base(fp, p, d) //??
        {
            speed = 2.0f;
        }

        /// <summary>
        /// Inputs for the Hero
        /// </summary>
        public virtual void Update(Vector2 offset, Hero hero)
        {
            AI(hero);

            base.Update(offset);
        }

        public virtual void AI(Hero hero)
        {
            pos += Globals.RadialMovement(hero.pos, pos, speed);
            rot = Globals.RotateTowards(pos, hero.pos); //Helps move in the same position that it is looking
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
