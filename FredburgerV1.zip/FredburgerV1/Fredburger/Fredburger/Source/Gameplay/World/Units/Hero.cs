﻿#region HeroIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
using Fredburger.Source.Gameplay.World.Projectiles; //Bullet
using Fredburger.Source.Gameplay.World; //Unit
#endregion

namespace Fredburger.Source.Gameplay.World.Units
{
    /// <summary>
    /// 
    /// </summary>
    public class Hero : Unit
    {
        //speed is inherited from Unit

        /// <summary>
        /// Constructor (needs same arguments since inherits from unit
        /// - 11:09 p2
        /// </summary>
        public Hero(string fp, Vector2 p, Vector2 d) : base(fp, p, d) //??
        {
            speed = 2.0f;
        }

        /// <summary>
        /// Inputs for the Hero
        /// </summary>
        public override void Update(Vector2 offset)
        {
            //Diagonal movement = ifs only
            //Restrict diagonal = if/elifs

            if(Globals.keyb.GetPress("A"))
            {
                pos = new Vector2(pos.X - speed, pos.Y); //same position except to the left 1
            }
            if (Globals.keyb.GetPress("S"))
            {
                pos = new Vector2(pos.X, pos.Y + speed); //same position except to the left 1
            }
            if (Globals.keyb.GetPress("D"))
            {
                pos = new Vector2(pos.X + speed, pos.Y); //same position except to the left 1
            }
            if (Globals.keyb.GetPress("W"))
            {
                pos = new Vector2(pos.X, pos.Y - speed); //same position except to the left 1
            }

            //Rotating the character towards the mouse
            rot = Globals.RotateTowards(pos, new Vector2(Globals.mouseb.newMousePos.X, Globals.mouseb.newMousePos.Y));

            if(Globals.mouseb.LeftClick()) //when mouse is clicked
            {
                GameGlobals.PassProjectile(new Bullet(new Vector2(pos.X,pos.Y), this, new Vector2(Globals.mouseb.newMousePos.X, Globals.mouseb.newMousePos.Y))); //calling World.AddProjectile here
            }

            base.Update(offset);
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
