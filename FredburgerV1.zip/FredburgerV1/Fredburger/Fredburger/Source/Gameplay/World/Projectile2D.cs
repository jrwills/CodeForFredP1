﻿#region Projectile2DIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
#endregion

namespace Fredburger.Source.Gameplay.World
{
    public class Projectile2D : Basic2D //because it draws itself
    {
        public bool doneFlag; //when projectile is finished

        public float speed;

        public Vector2 dir; //hit something or disipate after time

        public Unit owner; //owner of the projectile

        public EngTimer timer;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="fp"></param>
        /// <param name="p"></param>
        /// <param name="d"></param>
        /// <param name="o"></param>
        /// <param name="target"></param>
        public Projectile2D(string fp, Vector2 p, Vector2 d, Unit o, Vector2 target) : base(fp, p, d)
        {
            doneFlag = false;

            speed = 5.0f;

            owner = o;

            dir = target - o.pos; // vector - vector = directional vector
            dir.Normalize(); //We want a vector of length 1, because of its relation to speed 20:09 pt4

            rot = Globals.RotateTowards(pos, new Vector2(target.X, target.Y)); //For rotating the projectile

            timer = new EngTimer(1200); //1200 = 1.2 seconds
        }

        /// <summary>
        /// For testing collision, helps placing it outside of Units
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="units"></param>
        public virtual void Update(Vector2 offset, List<Unit> units)
        {
            pos += dir * speed; //To move the projectile

            timer.UpdateTimer();
            if(timer.Test()) //if the timer finishes
            {
                doneFlag = true; //gets rid of projectiles
            }

            if(CollisionDetection(units))
            {
                //tell the mob it is hit in here too
                doneFlag = true; //can never get here atm
            }
        }

        public virtual bool CollisionDetection(List<Unit> units)
        {
            for(int i = 0; i < units.Count; i++)
            {
                if(Globals.GetDistance(pos, units[i].pos) < units[i].hitDistance)
                {
                    units[i].Collision(); // "get hit"
                    return true; //projectile is done
                }
            }
            return false;
        }

        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
