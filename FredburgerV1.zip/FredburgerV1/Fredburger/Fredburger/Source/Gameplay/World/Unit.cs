﻿#region UnitIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
#endregion

namespace Fredburger.Source.Gameplay.World
{
    /// <summary>
    /// 
    /// </summary>
    public class Unit : Basic2D
    {
        public float speed;

        public bool dead;

        public float hitDistance;

        /// <summary>
        /// Constructor (needs same arguments since inherits from Basic2D
        /// </summary>
        public Unit(string fp, Vector2 p, Vector2 d) : base(fp, p, d) //??
        {
            dead = false; //initially false when a new mob is created
            speed = 2.0f;

            hitDistance = 35.0f;
        }

        /// <summary>
        /// Override
        /// </summary>
        public override void Update(Vector2 offset)
        {
            base.Update(offset);
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Collision() // "get hit"
        {
            dead = true;
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
