﻿#region BulletIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Basic 2D
#endregion

namespace Fredburger.Source.Gameplay.World.Projectiles
{
    public class Bullet : Projectile2D
    {

        /// <summary>
        /// Constructor.
        /// (Because it is a bullet WE KNOW what it looks like AND its dimensions)
        /// </summary>
        /// <param name="fp"></param>
        /// <param name="p"></param>
        /// <param name="d"></param>
        /// <param name="o"></param>
        /// <param name="target"></param>
        public Bullet(Vector2 p, Unit o, Vector2 target) : base("2D\\Projectiles\\bullet", p, new Vector2(20,20), o, target) //mess around with (20,20) , Vector2 d
        {
            //Done in Projectile2D
        }

        /// <summary>
        /// For testing collision, helps placing it outside of Units
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="units"></param>
        public override void Update(Vector2 offset, List<Unit> units)
        {
            base.Update(offset, units);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="offset"></param>
        public override void Draw(Vector2 offset)
        {
            base.Draw(offset);
        }
    }
}
