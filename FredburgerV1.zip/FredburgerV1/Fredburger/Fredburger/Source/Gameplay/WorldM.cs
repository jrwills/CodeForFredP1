﻿#region WorldIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //2D, EngTimer, Globals
using Fredburger.Source.Gameplay.World; //Projectile2D, SpawnPoint, UI, Unit
using Fredburger.Source.Gameplay.World.Units; //Hero, Mob
#endregion

namespace Fredburger.Source.Gameplay
{
    public class WorldM
    {
        public Hero spriteHero;

        public List<Projectile2D> projectiles = new List<Projectile2D>();
        public List<Mob> mobs = new List<Mob>();
        public List<SpawnPoint> spawnPoints = new List<SpawnPoint>();


        public Vector2 offset;

        /// <summary>
        /// Constructor
        /// </summary>
        public WorldM()
        {
            spriteHero = new Hero("2D\\ball", new Vector2(300, 300), new Vector2(48,48)); //"ball" working example png

            GameGlobals.PassProjectile = AddProjectile; //Set the delegate to the AddProjectile function
            GameGlobals.PassMob = AddMob; //Set the delegate to the AddMob function

            offset = new Vector2(0, 0);

            spawnPoints.Add(new SpawnPoint("2D\\Misc\\circle", new Vector2(50,50), new Vector2(35,35)));

            spawnPoints.Add(new SpawnPoint("2D\\Misc\\circle", new Vector2(Globals.screenWidth / 2, 50), new Vector2(35, 35)));
            spawnPoints[spawnPoints.Count - 1].spawnTimer.AddToTimer(500); //gets the last entry in the list | half a second

            spawnPoints.Add(new SpawnPoint("2D\\Misc\\circle", new Vector2(Globals.screenWidth - 50, 50), new Vector2(35, 35)));
            spawnPoints[spawnPoints.Count - 1].spawnTimer.AddToTimer(1000);
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Update() //virtual = for overloading just in case?
        {
            spriteHero.Update(offset); //at beginning of class "offset"

            for (int i = 0; i < spawnPoints.Count; i++)
            {
                spawnPoints[i].Update(offset); // ( offset, list of mobs)
            }

            for (int i = 0; i < projectiles.Count; i++)
            {
                projectiles[i].Update(offset, mobs.ToList<Unit>()); // ( offset, list of mobs)

                if(projectiles[i].doneFlag)
                {
                    projectiles.RemoveAt(i);
                    i--; //otherwise you may miss in a fuller list of projectiles
                }
            }

            for (int i = 0; i < mobs.Count; i++)
            {
                mobs[i].Update(offset, spriteHero); // ( offset, list of mobs)

                if (mobs[i].dead)
                {
                    mobs.RemoveAt(i);
                    i--; //otherwise you may miss in a fuller list of mobs
                }
            }
        }

        /// <summary>
        /// ONLY PASS PROJECTILES INTO ME
        /// </summary>
        /// <param name="info"></param>
        public virtual void AddProjectile(object info)
        {
            projectiles.Add((Projectile2D)info); //Added to the list of projectiles
        }

        /// <summary>
        /// Only pass mobs into me?
        /// </summary>
        /// <param name="info"></param>
        public virtual void AddMob(object info)
        {
            mobs.Add((Mob)info); //Added to the list of mobs
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Draw(Vector2 offset)
        {
            spriteHero.Draw(offset);

            for (int i = 0; i < projectiles.Count; i++)
            {
                projectiles[i].Draw(offset); // (offset)
            }

            for (int i = 0; i < spawnPoints.Count; i++)
            {
                spawnPoints[i].Draw(offset); // ( offset, list of mobs) 27.33
            }

            for (int i = 0; i < mobs.Count; i++)
            {
                mobs[i].Draw(offset); // (offset)
            }
        }
    }
}
