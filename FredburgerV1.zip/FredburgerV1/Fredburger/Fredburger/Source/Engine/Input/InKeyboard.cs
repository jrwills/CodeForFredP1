﻿#region InKeyboardIncludes
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine.Input.Keyboards; //InKey
#endregion

namespace Fredburger.Source.Engine.Input
{
    public class InKeyboard
    {

        public KeyboardState newKeyboard; //this frame
        public KeyboardState oldKeyboard; //previous frame

        public List<InKey> pressedKeys = new List<InKey>(), previousPressedKeys = new List<InKey>();

        public InKeyboard()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Update()
        {
            newKeyboard = Keyboard.GetState();

            GetPressedKeys();

        }

        /// <summary>
        /// At the very end of the frame
        /// </summary>
        public void UpdateOld()
        {
            oldKeyboard = newKeyboard;

            previousPressedKeys = new List<InKey>();
            for (int i = 0; i < pressedKeys.Count; i++)
            {
                previousPressedKeys.Add(pressedKeys[i]);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="KEY"></param>
        /// <returns></returns>
        public bool GetPress(string KEY)
        {
            for (int i = 0; i < pressedKeys.Count; i++)
            {
                if (pressedKeys[i].key == KEY)
                {
                    return true;
                }

            }


            return false;
        }

        /// <summary>
        /// Removes all the pressed keys, checks for every pressed key, then adding them
        /// </summary>
        public virtual void GetPressedKeys()
        {
            bool found = false;

            pressedKeys.Clear();
            for (int i = 0; i < newKeyboard.GetPressedKeys().Length; i++)
            {

                pressedKeys.Add(new InKey(newKeyboard.GetPressedKeys()[i].ToString(), 1));

            }
        }

    }
}
