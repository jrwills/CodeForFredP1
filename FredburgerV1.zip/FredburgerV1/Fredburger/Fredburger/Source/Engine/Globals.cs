﻿#region GlobalsIncludes
using System;
using System.Collections.Generic;
using System.Text; //?
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine.Input; //InKeyboard
#endregion

namespace Fredburger.Source.Engine
{
    //Delegate 1 - Create a class and stuff stuff in there
    public delegate void PassObject(object obj);
    //Delegate 2 - Same except returns an obj as well (33:00 pt4)
    public delegate object PassObjectAndReturn(object obj);


    public class Globals
    {
        public static int screenHeight;
        public static int screenWidth;

        public static ContentManager content; //images
        public static SpriteBatch spriteBatch; //what helps to draw them

        public static InKeyboard keyb;
        public static InMouseControl mouseb; //after creating the class STEP 2

        public static GameTime gameTimeb; //Monogame class keepign track of time between frames

        /// <summary>
        /// The distance formula
        /// </summary>
        /// <param name="cur"></param>
        /// <param name="target"></param>
        /// <returns></returns>
        public static float GetDistance(Vector2 cur, Vector2 target)
        {
            return (float)Math.Sqrt(Math.Pow(cur.X - target.X, 2) + Math.Pow(cur.Y - target.Y, 2));
            // sqrt((cur.X - target.X)^2 + (cur.Y - target.Y)^2
        }

        /// <summary>
        /// 19.56 pt3
        /// </summary>
        /// <param name="pos"></param>
        /// <param name="focus"></param>
        /// <returns></returns>
        public static float RotateTowards(Vector2 pos, Vector2 focus)
        {
            var direction = Vector2.Normalize(focus - pos);
            var angle = (float)Math.Acos(Vector2.Dot(direction, Vector2.UnitY));
            if (direction.X < 0) 
            { 
                return (float)Math.PI + angle; 
            }
            else 
            { 
                return (float)Math.PI - angle; 
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="focus"></param>
        /// <param name="pos"></param>
        /// <param name="speed"></param>
        /// <returns></returns>
        public static Vector2 RadialMovement(Vector2 focus, Vector2 pos, float speed)
        {
            float dist = Globals.GetDistance(pos, focus);

            if (dist <= speed)
            {
                return focus - pos; //directional vector
            }
            else
            {
                return (focus - pos) * speed / dist; //a portion of the direcitonal vector, not faster than the speed
            }
        }

    }
}
