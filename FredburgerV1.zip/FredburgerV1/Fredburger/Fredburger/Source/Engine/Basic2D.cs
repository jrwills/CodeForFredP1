﻿#region Basic2DIncludes
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
#endregion

namespace Fredburger.Source.Engine
{
    /// <summary>
    /// "basic" structure for a class (constructor, update and draw) for all game objects drawn
    /// </summary>
    public class Basic2D
    {
        public Vector2 pos; //2D position
        public Vector2 dim; //2D dimension

        public float rot; //rotation

        public Texture2D model;

        public Basic2D(string fp, Vector2 p, Vector2 d)
        {
            pos = p;
            dim = d;

            model = Globals.content.Load<Texture2D>(fp); //Should load in whatever we pass into it
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Update(Vector2 offset)
        {
            //nothing here?
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Draw(Vector2 offset) //offset
        {
            //null check
            if(model != null)
            {
                Globals.spriteBatch.Draw(model, new Rectangle((int)(pos.X + offset.X), (int)(pos.Y + offset.Y), (int)(dim.X), (int)(dim.Y)), null, 
                    Color.White, rot, new Vector2(model.Bounds.Width / 2, model.Bounds.Height / 2), new SpriteEffects(), 0); // div 2 helps to Draw from the middle | 0 for layerDepth
            }
            //Example: pos.X = relative position, offset.X = shifted position | height / width
        }

        /// <summary>
        /// New Overload Draw function
        /// </summary>
        public virtual void Draw(Vector2 offset, Vector2 origin) //offset
        {
            //null check
            if (model != null)
            {
                Globals.spriteBatch.Draw(model, new Rectangle((int)(pos.X + offset.X), (int)(pos.Y + offset.Y), (int)(dim.X), (int)(dim.Y)), null,
                    Color.White, rot, new Vector2(origin.X,origin.Y), new SpriteEffects(), 0);
            }
        }
    }
}
