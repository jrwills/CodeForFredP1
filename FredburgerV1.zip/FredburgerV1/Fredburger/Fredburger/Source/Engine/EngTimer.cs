﻿#region EngTimerIncludes
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
#endregion

namespace Fredburger.Source.Engine
{
    public class EngTimer
    {
        public bool boo; //right at beginning
        protected int mSec; //what milli we are at
        protected TimeSpan timer = new TimeSpan(); //Essentially keeps track of elapsed time

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="m"></param>
        public EngTimer(int m)
        {
            boo = false;
            mSec = m;
        }

        /// <summary>
        /// For TESTING w/ bool
        /// </summary>
        /// <param name="m"></param>
        /// <param name="STARTLOADED"></param>
        public EngTimer(int m, bool STARTLOADED)
        {
            boo = STARTLOADED;
            mSec = m;
        }

        /// <summary>
        /// 
        /// </summary>
        public int MSec
        {
            get { return mSec; }
            set { mSec = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int Timer
        {
            get { return (int)timer.TotalMilliseconds; }
        }


        /// <summary>
        /// Adds elapsed times to current timer
        /// </summary>
        public void UpdateTimer()
        {
            timer += Globals.gameTimeb.ElapsedGameTime;
        }

        /// <summary>
        /// For additional functions of speeding up or slowing down time [DEPENDS ON SPEED]
        /// </summary>
        /// <param name="SPEED"></param>
        public void UpdateTimer(float SPEED)
        {
            timer += TimeSpan.FromTicks((long)(Globals.gameTimeb.ElapsedGameTime.Ticks * SPEED));
        }

        /// <summary>
        /// Used when loading the game, saving, logging, etc. reducing cooldowns, etc.
        /// </summary>
        /// <param name="MSEC"></param>
        public virtual void AddToTimer(int MSEC)
        {
            timer += TimeSpan.FromMilliseconds((long)(MSEC));
        }

        /// <summary>
        /// Finding out if it is time to launch the _blank_
        /// </summary>
        /// <returns></returns>
        public bool Test()
        {
            if (timer.TotalMilliseconds >= mSec || boo)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Subtracts amount of time for the timer
        /// timing event when it is past the max time
        /// </summary>
        public void Reset()
        {
            timer = timer.Subtract(new TimeSpan(0, 0, mSec / 60000, mSec / 1000, mSec % 1000));
            if (timer.TotalMilliseconds < 0)
            {
                timer = TimeSpan.Zero;
            }
            boo = false;
        }

        /// <summary>
        /// Resets with a given value leftover
        /// </summary>
        /// <param name="NEWTIMER"></param>
        public void Reset(int NEWTIMER)
        {
            timer = TimeSpan.Zero;
            MSec = NEWTIMER;
            boo = false;
        }

        /// <summary>
        /// Simply resets the timer to 0
        /// </summary>
        public void ResetToZero()
        {
            timer = TimeSpan.Zero;
            boo = false;
        }

        public virtual XElement ReturnXML()
        {
            XElement xml = new XElement("Timer", new XElement("mSec", mSec), new XElement("timer", Timer));



            return xml;
        }

        /// <summary>
        /// Sets the timer
        /// </summary>
        /// <param name="TIME"></param>
        public void SetTimer(TimeSpan TIME)
        {
            timer = TIME;
        }

        /// <summary>
        /// Same instead just an int
        /// </summary>
        /// <param name="MSEC"></param>
        public virtual void SetTimer(int MSEC)
        {
            timer = TimeSpan.FromMilliseconds((long)(MSEC));
        }
    }
}
