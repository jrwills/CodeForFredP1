﻿#region GameGlobalsIncludes
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Fredburger.Source.Engine; //Access to delegates
//using Pong.Source.Gameplay.World; //Hero
#endregion

namespace Fredburger
{
    public class GameGlobals
    {
        public static PassObject PassProjectile; //Delegate #1 creation
        public static PassObject PassMob; //Delegate #3 creation
    }
}
