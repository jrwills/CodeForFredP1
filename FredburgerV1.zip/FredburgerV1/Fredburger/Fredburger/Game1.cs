﻿#region Game1Includes
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Fredburger.Source.Gameplay; //World
using Fredburger.Source.Engine; //Basic 2D and Globals
using Fredburger.Source.Engine.Input; //Inkeyboard, InMouseControl
#endregion

namespace Fredburger
{
    /// <summary>
    /// The main Game1 class inherits from the Game class, which provides all the core methods 
    /// for your game (ie. Load/Unload Content, Update, Draw etc.). 
    /// You usually only have one Game class per game, so its name isn't that important.
    /// </summary>
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        WorldM world;
        Basic2D cursor; //We need our cursor to appear on the screen

        /// <summary>
        /// Constructor
        /// </summary>
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = false; //changed to false after adding my own mouse cursor
        }

        /// <summary>
        /// 
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            Globals.screenHeight = 500; //900
            Globals.screenWidth = 800; //1600

            _graphics.PreferredBackBufferHeight = Globals.screenHeight;
            _graphics.PreferredBackBufferWidth = Globals.screenWidth;
            _graphics.ApplyChanges(); //if this isn't done, will not do anything!

            base.Initialize();
        }

        /// <summary>
        /// Anything not loaded in a load thread is loaded here, start load thread at the end of this
        /// </summary>
        protected override void LoadContent()
        {
            Globals.content = this.Content;
            Globals.spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            cursor = new Basic2D("2D\\cursor", new Vector2(0, 0), new Vector2(28, 28));//17.25 p3
            Globals.keyb = new InKeyboard();
            Globals.mouseb = new InMouseControl(); //STEP 3 after Globals.cs


            world = new WorldM();

        }

        /// <summary>
        /// Called once per game, trash collection
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: 
        }

        /// <summary>
        /// Logic for updating the world *LOTS HERE*
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            Globals.gameTimeb = gameTime;
            Globals.keyb.Update();//Keyboard updating
            Globals.mouseb.Update(); //Mouse updating here

            world.Update();

            Globals.keyb.UpdateOld(); //keyboard update old
            Globals.mouseb.UpdateOld(); //mouse update old STEP 4

            base.Update(gameTime);
        }

        /// <summary>
        /// Don't want a ton of logic here!
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            Globals.spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend); //param questions

            world.Draw(Vector2.Zero); //No screen shifting so 0,0 vector is okay

            cursor.Draw(new Vector2(Globals.mouseb.newMousePos.X, Globals.mouseb.newMousePos.Y), new Vector2(0, 0)); //(offset, origin)
            Globals.spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

